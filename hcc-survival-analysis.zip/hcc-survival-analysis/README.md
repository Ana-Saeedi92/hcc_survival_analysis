# HCC Survival Analysis in R

## Overview
This repository contains a cleaned, GitHub-ready version of an HCC SBRT survival analysis workflow.  
The original working script included:

- data import from a SAS dataset
- variable recoding and first-record-per-patient derivation
- descriptive statistics by treatment group
- Kaplan–Meier estimation for local control and overall survival
- restricted mean survival time (RMST)
- subgroup analyses by treatment interval
- univariate and multivariable Cox proportional hazards models

To keep this repository shareable, the code uses **simulated data** with a structure similar to the original project rather than real patient-level data.

## Repository structure

```text
hcc-survival-analysis/
├── README.md
├── .gitignore
├── data/
│   └── simulated_hcc_data.csv
├── code/
│   ├── 00_packages.R
│   ├── 01_simulate_data.R
│   ├── 02_prepare_data.R
│   ├── 03_descriptive_analysis.R
│   ├── 04_local_control_analysis.R
│   ├── 05_overall_survival_analysis.R
│   ├── 06_subgroup_analysis.R
│   ├── 07_cox_models.R
│   └── run_all.R
└── results/
    ├── figures/
    └── tables/
```

## Methods shown
- Kaplan–Meier survival estimation
- Log-rank tests
- RMST summary
- Reverse Kaplan–Meier for follow-up
- Univariate Cox models
- Multivariable Cox model with clinically motivated covariates

## Important note
The original script referenced a private SAS dataset and local Windows paths. Those have been removed here.  
This repo is intended to demonstrate **analytical workflow, code organization, and statistical reasoning**, not to distribute real clinical data.

## How to run

1. Open the project in RStudio.
2. Install any missing packages.
3. Run:

```r
source("code/run_all.R")
```

This will:
- create a simulated dataset
- prepare analysis datasets
- run descriptive analyses
- fit survival models
- save key tables and figures to `results/`

## Portfolio framing
This project is a good portfolio example because it shows:
- reproducible analytical structure
- applied survival analysis
- code modularization
- communication-ready outputs

## Suggested GitHub repo name
`hcc-survival-analysis`

## Suggested one-line description
Reproducible R workflow for HCC survival analysis using Kaplan–Meier, RMST, subgroup analyses, and Cox models.
