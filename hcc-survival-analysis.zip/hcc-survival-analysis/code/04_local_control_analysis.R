source("code/00_packages.R")

model_lc <- readRDS("data/model_lc.rds")

fit_lc_overall <- survfit(Surv(time_lc_yr, resp_fail) ~ 1, data = model_lc)
fit_lc_group <- survfit(Surv(time_lc_yr, resp_fail) ~ Desc_Salv_Consol, data = model_lc)

lc_prob <- summary(fit_lc_group, times = c(1, 2, 3, 4), extend = TRUE)

lc_prob_tbl <- tibble(
  time_year = lc_prob$time,
  group = gsub("Desc_Salv_Consol=", "", lc_prob$strata),
  n_risk = lc_prob$n.risk,
  n_event = lc_prob$n.event,
  survival = round(lc_prob$surv, 3),
  lower_95 = round(lc_prob$lower, 3),
  upper_95 = round(lc_prob$upper, 3)
)

write_csv(lc_prob_tbl, "results/tables/local_control_probabilities.csv")

p <- ggsurvplot(
  fit_lc_group,
  conf.int = FALSE,
  risk.table = TRUE,
  pval = TRUE,
  xlab = "Years from SBRT",
  ylab = "Local control probability",
  title = "Kaplan–Meier: Local Control by Treatment Group",
  xlim = c(0, 4),
  break.time.by = 1,
  ggtheme = theme_minimal()
)

ggsave("results/figures/local_control_by_group.png", p$plot, width = 8, height = 6, dpi = 300)

message("Saved local control outputs.")
