source("code/00_packages.R")

model_os <- readRDS("data/model_os.rds")

fit_os_overall <- survfit(Surv(time_os, status_os) ~ 1, data = model_os)
fit_os_group <- survfit(Surv(time_os, status_os) ~ Desc_Salv_Consol, data = model_os)

os_prob <- summary(fit_os_group, times = c(1, 2, 3, 4), extend = TRUE)

os_prob_tbl <- tibble(
  time_year = os_prob$time,
  group = gsub("Desc_Salv_Consol=", "", os_prob$strata),
  n_risk = os_prob$n.risk,
  n_event = os_prob$n.event,
  survival = round(os_prob$surv, 3),
  lower_95 = round(os_prob$lower, 3),
  upper_95 = round(os_prob$upper, 3)
)

write_csv(os_prob_tbl, "results/tables/overall_survival_probabilities.csv")

p <- ggsurvplot(
  fit_os_group,
  conf.int = FALSE,
  risk.table = TRUE,
  pval = TRUE,
  xlab = "Years from index date",
  ylab = "Overall survival probability",
  title = "Kaplan–Meier: Overall Survival by Treatment Group",
  xlim = c(0, 4),
  break.time.by = 1,
  ggtheme = theme_minimal()
)

ggsave("results/figures/overall_survival_by_group.png", p$plot, width = 8, height = 6, dpi = 300)

# Reverse KM for follow-up
fit_followup <- survfit(Surv(time_os, status_os == 0) ~ 1, data = model_os)
followup_summary <- summary(fit_followup)$table

followup_tbl <- tibble(
  metric = c("median_followup", "lower_95", "upper_95"),
  value = as.numeric(followup_summary[c("median", "0.95LCL", "0.95UCL")])
)

write_csv(followup_tbl, "results/tables/reverse_km_followup.csv")

message("Saved overall survival outputs.")
