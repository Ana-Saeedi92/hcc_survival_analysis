source("code/00_packages.R")

model_lc <- readRDS("data/model_lc.rds")
model_os <- readRDS("data/model_os.rds")

extract_hr <- function(fit, label) {
  s <- summary(fit)
  tibble(
    analysis = label,
    variable = rownames(s$coefficients),
    hr = round(exp(coef(fit)), 3),
    lower_95 = round(exp(confint(fit)[, 1]), 3),
    upper_95 = round(exp(confint(fit)[, 2]), 3),
    p_value = round(s$coefficients[, "Pr(>|z|)"], 4)
  )
}

# Univariate models
cox_lc_group <- coxph(Surv(time_lc_yr, resp_fail) ~ Desc_Salv_Consol, data = model_lc)
cox_lc_age <- coxph(Surv(time_3yr, status_3yr) ~ age_first_SBRT, data = model_lc)
cox_lc_size <- coxph(Surv(time_lc_yr, resp_fail) ~ hcc_size_gt3, data = model_lc)

cox_os_group <- coxph(Surv(time_os, status_os) ~ Desc_Salv_Consol, data = model_os)
cox_os_age <- coxph(Surv(time_os, status_os) ~ age_gt60, data = model_os)
cox_os_milan <- coxph(Surv(time_os, status_os) ~ Milan_criteria, data = model_os)
cox_os_pvtt <- coxph(Surv(time_os, status_os) ~ pvtt, data = model_os)

uni_tbl <- bind_rows(
  extract_hr(cox_lc_group, "LC: treatment group"),
  extract_hr(cox_lc_age, "LC: age"),
  extract_hr(cox_lc_size, "LC: tumor size >3 cm"),
  extract_hr(cox_os_group, "OS: treatment group"),
  extract_hr(cox_os_age, "OS: age >60"),
  extract_hr(cox_os_milan, "OS: Milan criteria"),
  extract_hr(cox_os_pvtt, "OS: PVTT")
)

write_csv(uni_tbl, "results/tables/univariate_cox_models.csv")

# Multivariable OS model
final_model_os <- coxph(
  Surv(time_os, status_os) ~ Desc_Salv_Consol + hcc_size_gt3 + pvtt + afp_prior_sbrt_cat + listed + transplant + cp_prior_group,
  data = model_os
)

multi_tbl <- extract_hr(final_model_os, "OS multivariable")
write_csv(multi_tbl, "results/tables/multivariable_os_cox_model.csv")

ph_tbl <- cox.zph(final_model_os)$table %>%
  as.data.frame() %>%
  rownames_to_column("term")

write_csv(ph_tbl, "results/tables/multivariable_os_ph_assumption.csv")

message("Saved Cox model outputs.")
