source("code/00_packages.R")

studyid_wise <- readRDS("data/studyid_wise.rds")
chart_data <- readRDS("data/chart_data.rds")

summarize_median_iqr <- function(data, var, group_var) {
  data %>%
    group_by(.data[[group_var]]) %>%
    summarise(
      median = median(.data[[var]], na.rm = TRUE),
      q1 = quantile(.data[[var]], 0.25, na.rm = TRUE),
      q3 = quantile(.data[[var]], 0.75, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      variable = var,
      summary = sprintf("%.1f (%.1f, %.1f)", median, q1, q3)
    ) %>%
    select(variable, group = .data[[group_var]], summary)
}

continuous_vars <- c("age_first_SBRT", "hcc_size_sbrt", "gtv", "ptv", "td", "n_fx", "eqd2", "mld")

desc_tbl <- bind_rows(lapply(continuous_vars, summarize_median_iqr, data = chart_data, group_var = "Desc_Salv_Consol"))
write_csv(desc_tbl, "results/tables/descriptive_summary.csv")

message("Saved descriptive summary table.")
