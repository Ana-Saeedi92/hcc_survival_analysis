# ---- Packages ----
required_packages <- c(
  "dplyr",
  "readr",
  "survival",
  "survminer",
  "ggplot2",
  "stringr",
  "tibble"
)

missing_packages <- required_packages[!required_packages %in% rownames(installed.packages())]

if (length(missing_packages) > 0) {
  install.packages(missing_packages)
}

invisible(lapply(required_packages, library, character.only = TRUE))
