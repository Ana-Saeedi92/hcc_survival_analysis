source("code/00_packages.R")

set.seed(1234)

n <- 120

sim_data <- tibble(
  study_id = 1:n,
  unique_id = sprintf("ID_%03d", 1:n),
  Desc_Salv_Consol = factor(sample(c("Salvage", "CMT"), n, replace = TRUE, prob = c(0.45, 0.55))),
  age_first_SBRT = round(rnorm(n, mean = 64, sd = 9)),
  Milan_criteria = factor(sample(c("No", "Yes"), n, replace = TRUE, prob = c(0.35, 0.65))),
  pvtt = factor(sample(c("No", "Yes"), n, replace = TRUE, prob = c(0.80, 0.20))),
  listed = factor(sample(c("No", "Yes"), n, replace = TRUE, prob = c(0.55, 0.45))),
  transplant = factor(sample(c("No", "Yes"), n, replace = TRUE, prob = c(0.82, 0.18))),
  cp_prior_group = factor(sample(c("A", "B/C"), n, replace = TRUE, prob = c(0.60, 0.40))),
  afp_prior_sbrt = round(rlnorm(n, meanlog = log(12), sdlog = 0.7), 1),
  hcc_size_sbrt = round(rlnorm(n, meanlog = log(2.8), sdlog = 0.35), 1),
  eqd2 = round(rnorm(n, mean = 78, sd = 8), 1),
  gtv = round(rlnorm(n, meanlog = log(35), sdlog = 0.6), 1),
  ptv = round(rlnorm(n, meanlog = log(60), sdlog = 0.7), 1),
  td = round(rnorm(n, mean = 45, sd = 8), 1),
  n_fx = sample(3:10, n, replace = TRUE),
  mld = round(rlnorm(n, meanlog = log(11), sdlog = 0.35), 1),
  date_last_LDT = as.Date("2020-01-01") + sample(0:365, n, replace = TRUE),
  sbrt_end = as.Date("2020-01-01") + sample(60:540, n, replace = TRUE),
  months_treat_time = round(runif(n, min = 1, max = 12), 1),
  resp = sample(c("CPD", "CR", "PR", "SD"), n, replace = TRUE, prob = c(0.18, 0.22, 0.28, 0.32)),
  time_lc_yr = round(pmin(rexp(n, rate = 0.30), 5), 2),
  resp_fail = 0L,
  time_os = round(pmin(rexp(n, rate = 0.20), 7), 2),
  status_os = rbinom(n, 1, 0.38)
) %>%
  mutate(
    resp_fail = if_else(resp == "CPD", 1L, 0L),
    subgroup = factor(
      if_else(months_treat_time < 6, "<6 months treatment", "≥6 months treatment"),
      levels = c("<6 months treatment", "≥6 months treatment")
    )
  )

write_csv(sim_data, "data/simulated_hcc_data.csv")
message("Simulated dataset written to data/simulated_hcc_data.csv")
