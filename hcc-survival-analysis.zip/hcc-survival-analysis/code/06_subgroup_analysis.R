source("code/00_packages.R")

model_lc <- readRDS("data/model_lc.rds")
model_os <- readRDS("data/model_os.rds")

fit_lc_subgroup <- survfit(Surv(time_lc_yr, resp_fail) ~ subgroup, data = model_lc)
fit_os_subgroup <- survfit(Surv(time_os, status_os) ~ subgroup, data = model_os)

rmst_table <- function(fit, tau, label) {
  tbl <- summary(fit, rmean = tau)$table %>%
    as.data.frame() %>%
    rownames_to_column("group") %>%
    transmute(
      analysis = label,
      group = sub("^.*=", "", group),
      n = records,
      events = events,
      tau = tau,
      rmst = round(rmean, 2),
      se_rmst = round(`se(rmean)`, 2),
      lower_95 = round(rmean - 1.96 * `se(rmean)`, 2),
      upper_95 = round(rmean + 1.96 * `se(rmean)`, 2)
    )
  tbl
}

rmst_lc <- rmst_table(fit_lc_subgroup, tau = 3.5, label = "Local control")
rmst_os <- rmst_table(fit_os_subgroup, tau = 4.5, label = "Overall survival")

bind_rows(rmst_lc, rmst_os) %>%
  write_csv("results/tables/subgroup_rmst.csv")

p1 <- ggsurvplot(
  fit_lc_subgroup,
  conf.int = FALSE,
  risk.table = TRUE,
  pval = TRUE,
  xlab = "Years from SBRT",
  ylab = "Local control probability",
  title = "Local Control by Treatment Interval",
  xlim = c(0, 4),
  break.time.by = 1,
  ggtheme = theme_minimal()
)

p2 <- ggsurvplot(
  fit_os_subgroup,
  conf.int = FALSE,
  risk.table = TRUE,
  pval = TRUE,
  xlab = "Years from index date",
  ylab = "Overall survival probability",
  title = "Overall Survival by Treatment Interval",
  xlim = c(0, 4),
  break.time.by = 1,
  ggtheme = theme_minimal()
)

ggsave("results/figures/lc_by_subgroup.png", p1$plot, width = 8, height = 6, dpi = 300)
ggsave("results/figures/os_by_subgroup.png", p2$plot, width = 8, height = 6, dpi = 300)

message("Saved subgroup outputs.")
