source("code/01_simulate_data.R")
source("code/02_prepare_data.R")
source("code/03_descriptive_analysis.R")
source("code/04_local_control_analysis.R")
source("code/05_overall_survival_analysis.R")
source("code/06_subgroup_analysis.R")
source("code/07_cox_models.R")

message("All analyses completed successfully.")
