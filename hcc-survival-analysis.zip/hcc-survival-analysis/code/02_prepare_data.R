source("code/00_packages.R")

chart_data <- read_csv("data/simulated_hcc_data.csv", show_col_types = FALSE)

studyid_wise <- chart_data %>%
  arrange(study_id) %>%
  group_by(study_id) %>%
  slice(1) %>%
  ungroup()

model_lc <- chart_data %>%
  mutate(
    time_3yr = pmin(time_lc_yr, 3),
    status_3yr = if_else(resp_fail == 1 & time_lc_yr <= 3, 1L, 0L),
    hcc_size_gt3 = factor(if_else(hcc_size_sbrt > 3, "Yes", "No")),
    eqd2_gt80 = factor(if_else(eqd2 > 80, "Yes", "No"))
  )

model_os <- studyid_wise %>%
  mutate(
    age_gt60 = factor(if_else(age_first_SBRT > 60, "Yes", "No")),
    afp_prior_sbrt_cat = factor(if_else(afp_prior_sbrt >= 10, ">=10", "<10")),
    hcc_size_gt3 = factor(if_else(hcc_size_sbrt > 3, "Yes", "No")),
    eqd2_gt80 = factor(if_else(eqd2 > 80, "Yes", "No"))
  )

saveRDS(chart_data, "data/chart_data.rds")
saveRDS(studyid_wise, "data/studyid_wise.rds")
saveRDS(model_lc, "data/model_lc.rds")
saveRDS(model_os, "data/model_os.rds")

message("Prepared analysis datasets saved to data/*.rds")
